#ifndef TEST2_MAIN_H
#define TEST2_MAIN_H

#endif //TEST2_MAIN_H

#include "test2.h"

DPT *move();
void scan_board();
