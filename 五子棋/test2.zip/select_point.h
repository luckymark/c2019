#ifndef TEST2_SELECT_POINT_H
#define TEST2_SELECT_POINT_H

#endif //TEST2_SELECT_POINT_H

#include "test2.h"

BOOL have_neighbour(int x, int y);
