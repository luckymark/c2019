#ifndef TEST2_MOVE_H
#define TEST2_MOVE_H

#endif //TEST2_MOVE_H

#include "test2.h"

DPT *select_point();
int judge_turn();
DPT *dp(DPT *head, int turn, int height);
int evalue(DPT *head, int turn);
