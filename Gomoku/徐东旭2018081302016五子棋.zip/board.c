#include "Gomoku.h"
void draw_board(struct board (*map)[15]){
	system("cls");
	int i, j;
	for(i=0;i<len;i++){
		for(j=0;j<wid;j++){
			if(map[i][j].status==1){
					printf("��");
			}
			else if(map[i][j].chess==1){
				printf("��");
			}
			else if(map[i][j].chess==2){
				printf("��");
			}
			else{
				if(i==0&&j==0)printf("�� ");
				else if(i==0&&j==wid-1)printf("�� ");
				else if(i==0)printf("�� ");
				else if(i==len-1&&j==0)printf("�� ");
				else if(i==len-1&&j==wid-1)printf("�� ");
				else if(i==len-1)printf("�� ");
				else if(j==len-1)printf("�� ");
				else if(j==0)printf("�� ");
				else printf("�� ");
			}
		}
		printf("\n");
	}
}
