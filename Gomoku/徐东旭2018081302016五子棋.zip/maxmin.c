#include "search.h"
#include "value.h"
#include "Gomoku.h"
extern int lab_x, lab_y;
int MaxMinSearch(struct board (*map)[15],int depth,int x, int y){/*����˸��µ�λ��*/

	struct board temp[15][15];
	int i=0; int j=0;
	for(i=0;i<wid;i++){
		for(j=0;j<wid;j++){
			temp[i][j].chess=map[i][j].chess;
		}
	}
	if(depth==0){
		return score_board(temp,1)-score_board(temp,2);
	}
	int xmax=0;
	int ymax=0;
	int m=0;int max =0;
	int n=0;int min =10000000;
	int i0, j0;
	for(i0=0;i0<wid;i0++){
		for(j0=0;j0<wid;j0++){
			if(temp[i0][j0].chess==0){
				if(depth%2==0){   
					temp[i0][j0].chess=2; 
					n=MaxMinSearch(temp,depth-1,i0,j0);
					if(n<min){
						min=n;
						xmax=i0;
						ymax=j0;
					}
					temp[i0][j0].chess=0; 
				}
				else if(depth%2==1){
					temp[i0][j0].chess=1;
					m=MaxMinSearch(temp,depth-1,i0,j0); 
					if(max<m){/*��һ�㷵�ص�ֵ���Ǽ�����*/ 
						max=m;
						xmax=i0;
						ymax=j0;
					}
					temp[i0][j0].chess=0; 
				}
			}
		}
	}
	lab_x=xmax;
	lab_y=ymax;
	
	if(depth%2==1) {/*return score_board(temp,2);*/
		temp[xmax][ymax].chess=1;
		return max;
	}
	else {
		temp[xmax][ymax].chess=2;
		return min;/*return score_board(temp,1);*/ 
	}
} 	
