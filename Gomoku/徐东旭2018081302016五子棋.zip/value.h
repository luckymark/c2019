#include "Gomoku.h"
void envalue(struct board (*map)[15]);/*���� */
int score(struct board (*map)[15], int row, int col, int role);
int alive_four(struct board (*map)[15], int row, int col,int chess);
int dead_four(struct board (*map)[15], int row, int col,int chess);
int alive_three(struct board (*map)[15], int row, int col,int chess);
int alive_two(struct board (*map)[15], int row, int col,int chess);
int aone(struct board (*map)[15], int row, int col,int chess);
int sleep_three(struct board (*map)[15],int row,int col,int chess);/*����*/ 
int score_board(struct board (*map)[15],int role);
