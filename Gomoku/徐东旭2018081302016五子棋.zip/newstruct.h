#ifndef STRU_H
#define STRU_H
struct board{
	int chess;
	int status;
	int value;
};
#endif
