#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <windows.h>
#include "newstruct.h"
#define len 15
#define wid 15
#define deep 6 
#define win 999999

struct board map[15][15];
void game_start(struct board (*map)[15]);
void draw_board(struct board (*map)[15]);
void player_go(struct board (*map)[15]); /*let player go*/
void ai_go(struct board (*map)[15]);
void up(struct board (*map)[15]);
void down(struct board (*map)[15]);
void right(struct board (*map)[15]);
void go(struct board (*map)[15]);
void left(struct board (*map)[15]);

int judge(struct board (*map)[15],int val);/*�ж�˭ʤ�� */
int row_judge(struct board (*map)[15],int val);
int col_judge(struct board (*map)[15],int val);
int left_judge(struct board (*map)[15],int val);
int right_judge(struct board (*map)[15],int val);


