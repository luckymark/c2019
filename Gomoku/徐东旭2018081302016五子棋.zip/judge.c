#include "Gomoku.h"
extern int lab_x, lab_y;
int judge(struct board (*map)[15],int val){
	int m=0;
	m+=row_judge(map,val);
	m+=col_judge(map,val);
	m+=left_judge(map,val);
	m+=right_judge(map,val);
	if(m==0)return m;
	else return val;
}
int row_judge(struct board (*map)[15],int val){
	int x=lab_x;int y=lab_y;
	int cnt=0;
	int i;
	for(i=y;i<len;i++){
		if(map[x][i].chess==val)cnt++;
		else break;
	}
	for(i=y-1;i>=0;i--){
		if(map[x][i].chess==val)cnt++;
		else break;
	}
	if(cnt>=5)return 1;
	else return 0;
}
int col_judge(struct board (*map)[15],int val){
	int x=lab_x;int y=lab_y;
	int cnt=0;
	int i;
	for(i=x;i<len;i++){
		if(map[i][y].chess==val)cnt++;
		else break;
	}
	for(i=x-1;i>=0;i--){
		if(map[i][y].chess==val)cnt++;
		else break;
	}
	if(cnt>=5)return 1;
	else return 0;
}
int left_judge(struct board (*map)[15],int val){
	int x=lab_x;int y=lab_y;
	int cnt=0;
	int i,j;
	for(i=x,j=y;i>=0&&j>=0;i--,j--){
		if(map[i][j].chess==val)cnt++;
		else break;
	}
	for(i=x+1,j=y+1;i<len&&j<len;i++,j++){
		if(map[i][j].chess==val)cnt++;
		else break;
	}
	if(cnt>=5)return 1;
	else return 0;
}
int right_judge(struct board (*map)[15],int val){
	int x=lab_x;int y=lab_y;
	int cnt=0;
	int i,j;
	for(i=x,j=y;i<len&&j>=0;i++,j--){
		if(map[i][j].chess==val)cnt++;
		else break;
	}
	for(i=x-1,j=y+1;i>=0&&j<len;i--,j++){
		if(map[i][j].chess==val)cnt++;
		else break;
	}
	if(cnt>=5)return 1;
	else return 0;
}
