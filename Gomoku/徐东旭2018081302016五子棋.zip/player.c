#include "Gomoku.h"
extern int lab_x, lab_y;
void player_go(struct board (*map)[15]){
	int decide=0;
	while(decide==0){
		char ch=getch();	
		switch (ch){
			case 119:/*up*/ 
				up(map);
				break;
			case 115:/*down*/
				down(map);
		 		break;
	 		case 97:/*left*/
	 			left(map);
	 			break;
 			case 100:
			 	right(map);
 				break;
			case 13:
				if(map[lab_x][lab_y].chess==0){
					go(map);
					decide=1;
				}	
		}
	}
			
}
void up(struct board (*map)[15]) {
	 if(lab_x!=0){
	 	map[lab_x][lab_y].status=0;
	 	lab_x--;
	 	map[lab_x][lab_y].status=1;
	 }
	 draw_board(map);
}
void down(struct board (*map)[15]){
	if(lab_x!=len-1){
		map[lab_x][lab_y].status=0;
	 	lab_x++;
	 	map[lab_x][lab_y].status=1;
	}
	draw_board(map);
}
void left(struct board (*map)[15]){
	if(lab_y!=0){
		map[lab_x][lab_y].status=0;
	 	lab_y--;
	 	map[lab_x][lab_y].status=1;
	}
	draw_board(map);
}
void right(struct board (*map)[15]){
	if(lab_y!=len-1){
		map[lab_x][lab_y].status=0;
	 	lab_y++;
	 	map[lab_x][lab_y].status=1;
	}
	draw_board(map);
}
void go(struct board (*map)[15]){
	map[lab_x][lab_y].status=0;
	map[lab_x][lab_y].chess=1;
	draw_board(map);
}

