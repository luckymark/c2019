#include "Gomoku.h"
int main(){
	game_start(map);
	return 0;
}
