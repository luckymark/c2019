#include "newstruct.h"
int MaxMinSearch(struct board (*map)[15],int depth,int x, int y);
